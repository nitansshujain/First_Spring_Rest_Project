package com.amdocs.FirstSpringRestProject.DAO;


import com.amdocs.FirstSpringRestProject.entity.Employee;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class EmployeeDAOImp implements EmployeeDAO {

    private final EntityManager entityManager;


    public EmployeeDAOImp(EntityManager theEntityManager) {

        this.entityManager = theEntityManager;
    }

    @Transactional
    @Override
    public List<Employee> findAll() {
        // Getting the current session of Hibernate
        Session currentSession =
                entityManager.unwrap(Session.class);
        Query<Employee> theQuery =
                currentSession.createQuery("From Employee", Employee.class);
        List<Employee> employees = theQuery.getResultList();
        //System.out.println(employees);
        return employees;

    }


    @Transactional
    @Override
    public Employee findById(int theId) {
        // TODO Auto-generated method stub
        Session currentSession =
                entityManager.unwrap(Session.class);
        Employee employee = currentSession.get(Employee.class, theId);
        return employee;
    }

    @Transactional
    @Override
    public Employee save(Employee theEmployee) {
        Session currentSession =
                entityManager.unwrap(Session.class);
        currentSession.saveOrUpdate(theEmployee);
        return theEmployee;
    }

    @Override
    @Transactional
    public void deleteById(int theId) {
        // TODO Auto-generated method stub
        Session currentSession =
                entityManager.unwrap(Session.class);

        currentSession.createQuery("From Employee where id=:empsId");

        Query<Employee> theQuery =
                currentSession.createQuery("delete From Employee where id=:empsId");
        theQuery.setParameter("empsId", theId);
        theQuery.executeUpdate();

    }

}
