package com.amdocs.FirstSpringRestProject.controller;

import com.amdocs.FirstSpringRestProject.entity.Employee;
import com.amdocs.FirstSpringRestProject.service.EmployeeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")

public class EmployeeRestController {

    //private EmployeeDAO employeeDAO;
    public EmployeeService employeeService;

    public EmployeeRestController(EmployeeService theEmployeeService) {
        this.employeeService = theEmployeeService;
    }

    //@GetMapping("/employees/{employeeId}")

    @GetMapping("/employees")

    public List<Employee> findAll() {
        return employeeService.findAll();
    }


    @GetMapping("/employees/{employeeId}")
    public Employee findById(@PathVariable int employeeId) {
        Employee employee = employeeService.findById(employeeId);
        if (employee == null) {
            throw new EmployeeNotFoundException("Employee Id Not Found ... " + employeeId);
        }

        return employee;
    }

    @PostMapping("/employees")
    public Employee addEmployee(@RequestBody Employee theEmployee) {
        Employee employee = employeeService.save(theEmployee);
        return employee;
    }

    @PutMapping("/employees")
    public Employee updateEmployee(@RequestBody Employee theEmployee) {
        Employee employee = employeeService.save(theEmployee);
        return employee;
    }

    @PatchMapping("/employees")
    public Employee update1Employee(@RequestBody Employee theEmployee) {
        Employee employee = employeeService.save(theEmployee);
        return employee;
    }

    @DeleteMapping("/employees/{employeeId}")
    public void deleteById(@PathVariable int employeeId) {
        //Employee employee=employeeService.deleteById(employeeId);
        employeeService.deleteById(employeeId);
        //return  employee;
    }


}
